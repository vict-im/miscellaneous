﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GraphSharp.Algorithms.Layout.Simple.FDP
{
    public enum FRCoolingFunction
    {
        Linear,
        Exponential
    }
}
