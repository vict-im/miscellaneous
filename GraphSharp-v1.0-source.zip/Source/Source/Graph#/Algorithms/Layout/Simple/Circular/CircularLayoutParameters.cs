﻿namespace GraphSharp.Algorithms.Layout.Simple.Circular
{
	public class CircularLayoutParameters : LayoutParametersBase
	{
		
	}
}