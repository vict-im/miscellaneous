﻿using System;
using System.ComponentModel;

namespace GraphSharp.Algorithms.Highlight
{
	public interface IHighlightParameters : ICloneable, INotifyPropertyChanged
	{
	}
}