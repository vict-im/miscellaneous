﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GraphSharp.Sample
{
    public class PocGraphEditor
    {
        private PocVertex sourceVertex = null;
        private PocVertex targetVertex = null;

        public PocGraph EditedGraph { get; set; }
    }
}
