﻿namespace GraphSharp.Controls
{
    public class FadeOutTransition : FadeTransition
    {
        public FadeOutTransition()
            : base( 1.0, 0.0 )
        {

        }
    }
}
